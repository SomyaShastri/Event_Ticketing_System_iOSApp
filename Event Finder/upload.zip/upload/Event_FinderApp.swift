//
//  Event_FinderApp.swift
//  Event Finder
//
//  Created by Somya Shastri on 4/13/23.
//

import SwiftUI

@main
struct Event_FinderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
